﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallclimb : MonoBehaviour {

    public float speed = 6;
    public Animator animator;

    // Use this for initialization
    void Start()
    {
        animator.SetBool("IsClimbing", false);
    }

    // Update is called once per frame
    void Update()
    {

    }


    void OnTriggerStay2D(Collider2D other)
    {
        if (other.tag == "Player" && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)))
        {
            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, speed);
            animator.SetBool("IsClimbing", true);

        }
        else if (other.tag == "Player" && (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)))
        {
            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, -speed);
            animator.SetBool("IsClimbing", true);

        }
        else
        {

            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0.59f);
            //animator.SetBool("IsClimbing", true);
        }
        if (other.tag == "Player" && (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)))
        {
            animator.SetBool("IsClimbing", false);
        } else if (other.tag == "Player" && (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)))
        {
            animator.SetBool("IsClimbing", false);
        }



    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            animator.SetBool("IsClimbing", false);
        }
    }
}

