﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera_follow : MonoBehaviour {
    //what will be followed
    public Transform target;

    //velocity is zero
    Vector3 velocity = Vector3.zero;

    //time to follow target
    public float smoothTime = .15f;

    //enable and set max y value
    public bool YmaxEnable = false;
    public float YmaxValue = 0;

    //enable and set min y value
    public bool YminEnable = false;
    public float YminValue = 0;

    //enable and set max x value
    public bool XmaxEnable = false;
    public float XmaxValue = 0;


    //enable and set min x value
    public bool XminEnable = false;
    public float XminValue = 0;

    void FixedUpdate()
    {
        //capture target position
        Vector3 targetPos = target.position;


        //vertical
        if(YminEnable && YmaxEnable)
        {
            targetPos.y = Mathf.Clamp(target.position.y,YminValue,YmaxValue);
        }else if(YminEnable)
        {
            targetPos.y = Mathf.Clamp(target.position.y, YminValue, target.position.y);
        }else if(YmaxEnable)
        {
            targetPos.y = Mathf.Clamp(target.position.y, target.position.y, YmaxValue);
        }

        //horizontal
        if (XminEnable && XmaxEnable)
        {
            targetPos.x = Mathf.Clamp(target.position.x, XminValue, XmaxValue);
        }
        else if (XminEnable)
        {
            targetPos.x = Mathf.Clamp(target.position.x, XminValue, target.position.x);
        }
        else if (XmaxEnable)
        {
            targetPos.x = Mathf.Clamp(target.position.x, target.position.x, XmaxValue);
        }





        //align camera and traget z position
        targetPos.z = transform.position.z;

        transform.position = Vector3.SmoothDamp(transform.position, targetPos, ref velocity, smoothTime);

    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
