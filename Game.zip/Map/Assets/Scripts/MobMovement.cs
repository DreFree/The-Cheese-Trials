﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MobMovement : MonoBehaviour
{

    public float moveSpeed;
    private Vector2 minWalkPoint;
    private Vector2 maxWalkPoint;

    private Rigidbody2D myRigidbody;

    public bool isWalking;

    public float walkTime;
    private float walkCounter;
    public float waitTime;
    private float waitCounter;
    private int counter = 0;

    private int WalkDirection;

    public Collider2D walkZone;
    private bool hasWalkZone;
 
    // Use this for initialization
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        waitCounter = waitTime;
        walkCounter = walkTime;

        ChooseDirection();
        if (walkZone != null)
        {
            minWalkPoint = walkZone.bounds.min;
            maxWalkPoint = walkZone.bounds.max;
            hasWalkZone = true;
        }
       


    }

    // Update is called once per frame
    void Update()
    {

        if (isWalking)
        {
            walkCounter -= Time.deltaTime;



            switch (WalkDirection)
            {
                case 0:

                    myRigidbody.velocity = new Vector2(moveSpeed, 0);
                    if (hasWalkZone && transform.position.x > maxWalkPoint.x)
                    {
                        
                        isWalking = false;
                        waitCounter = waitTime;

                    }

                    break;
                case 1:

                    myRigidbody.velocity = new Vector2(-moveSpeed, 0);
                    if (hasWalkZone && transform.position.x < minWalkPoint.x)
                    {
                        
                        isWalking = false;
                        waitCounter = waitTime;

                    }

                    break;


            }
            if (walkCounter < 0)
            {
                isWalking = false;
                waitCounter = waitTime;

            }

        }
        else
        {
            waitCounter -= Time.deltaTime;

            myRigidbody.velocity = Vector2.zero;

            if (waitCounter < 0)
            {
                ChooseDirection();

            }
        }

    }

    public void ChooseDirection()
    {
        if (counter == 0)
        {
            WalkDirection = 0;
            counter += 1;
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
        else if (counter == 1)
        {
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
            WalkDirection = 1;
            counter -= 1;
        }


        isWalking = true;
        walkCounter = walkTime;
    }
}